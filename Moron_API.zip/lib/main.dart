import 'package:api/home_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    title: 'API',
    debugShowCheckedModeBanner: false,
    home: HomePage()
  ));
}

